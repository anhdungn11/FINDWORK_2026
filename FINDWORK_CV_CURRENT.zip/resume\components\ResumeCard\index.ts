export { default } from "./ResumeCard";
