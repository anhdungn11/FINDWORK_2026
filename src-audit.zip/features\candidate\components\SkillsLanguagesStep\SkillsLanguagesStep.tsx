import { useState } from "react";

import type {
  CandidateLanguageItem,
  CandidateSkillItem,
  LanguageCertificateItem,
  LanguageCertificateScoreItem,
  LanguageProficiency,
} from "@/features/candidate/types/onboarding.types";

import {
  LANGUAGE_OPTIONS,
  getCertificateLabel,
  getCertificateTypeByCode,
  getCertificateTypesForLanguage,
  getLanguageLabel,
} from "@/features/candidate/utils/language.constants";

import {
  OTHER_SKILL_CODE,
  getSkillCategoryName,
  getSkillIdentity,
  getSkillName,
  searchSkills,
} from "@/features/candidate/utils/skill.constants";

import styles from "./SkillsLanguagesStep.module.css";

interface SkillsLanguagesStepProps {
  skills: CandidateSkillItem[];
  languages: CandidateLanguageItem[];

  onSkillsChange: (
    value: CandidateSkillItem[],
  ) => void;

  onLanguagesChange: (
    value: CandidateLanguageItem[],
  ) => void;
}

interface EditingCertificate {
  languageId: string;
  certificateId: string;
}

/* =========================================================
   FACTORIES
========================================================= */

const createSkill = (): CandidateSkillItem => ({
  id: crypto.randomUUID(),

  skillCode: "",
  customSkillName: "",

  level: "",

  yearsOfExperience: "",

  isHighlighted: false,
});

const createLanguage =
  (): CandidateLanguageItem => ({
    id: crypto.randomUUID(),

    languageCode: "",
    customLanguageName: "",

    overallLevel: "",

    listeningLevel: "",
    speakingLevel: "",
    readingLevel: "",
    writingLevel: "",

    certificates: [],
  });

const createCertificate =
  (): LanguageCertificateItem => ({
    id: crypto.randomUUID(),

    certificateTypeCode: "",
    customCertificateName: "",

    level: "",
    overallScore: "",

    scores: [],

    issuedDate: "",
    expiryDate: "",

    issuer: "",
    credentialId: "",
    verificationUrl: "",
  });

/* =========================================================
   LABEL HELPERS
========================================================= */



const getSkillLevelLabel = (
  level: CandidateSkillItem["level"],
) => {
  const labels: Record<
    Exclude<
      CandidateSkillItem["level"],
      ""
    >,
    string
  > = {
    beginner: "Cơ bản",
    intermediate: "Trung bình",
    advanced: "Khá",
    proficient: "Thành thạo",
    expert: "Chuyên gia",
  };

  if (!level) {
    return "Chưa cập nhật mức độ";
  }

  return labels[level];
};

const getLanguageLevelLabel = (
  level: LanguageProficiency,
) => {
  const labels: Record<
    Exclude<LanguageProficiency, "">,
    string
  > = {
    basic: "Cơ bản",
    conversational: "Giao tiếp",
    professional: "Làm việc chuyên nghiệp",
    fluent: "Thành thạo",
    native: "Bản ngữ",
  };

  if (!level) {
    return "Chưa cập nhật trình độ";
  }

  return labels[level];
};

/* =========================================================
   COMPONENT
========================================================= */

const SkillsLanguagesStep = ({
  skills,
  languages,
  onSkillsChange,
  onLanguagesChange,
}: SkillsLanguagesStepProps) => {
  const [
    editingSkillId,
    setEditingSkillId,
  ] = useState<string | null>(null);

  const [
    editingLanguageId,
    setEditingLanguageId,
  ] = useState<string | null>(null);

  const [
    editingCertificate,
    setEditingCertificate,
  ] =
    useState<EditingCertificate | null>(
      null,
    );

  const [
    skillError,
    setSkillError,
  ] = useState("");

  const [
    languageError,
    setLanguageError,
  ] = useState("");

  const [
    certificateError,
    setCertificateError,
  ] = useState("");

  const [
    skillSearchValues,
    setSkillSearchValues,
  ] = useState<Record<string, string>>({});

    /* =======================================================
     SKILLS
  ======================================================= */

  const addSkill = () => {
    const skill = createSkill();

    onSkillsChange([
      ...skills,
      skill,
    ]);

    setSkillSearchValues(
      (current) => ({
        ...current,
        [skill.id]: "",
      }),
    );

    setEditingSkillId(
      skill.id,
    );

    setSkillError("");
  };

  const updateSkill = <
    Key extends keyof CandidateSkillItem,
  >(
    id: string,
    key: Key,
    value: CandidateSkillItem[Key],
  ) => {
    onSkillsChange(
      skills.map((skill) =>
        skill.id === id
          ? {
              ...skill,
              [key]: value,
            }
          : skill,
      ),
    );
  };

  const removeSkill = (
    id: string,
  ) => {
    onSkillsChange(
      skills.filter(
        (skill) =>
          skill.id !== id,
      ),
    );

    setSkillSearchValues(
      (current) => {
        const next = {
          ...current,
        };

        delete next[id];

        return next;
      },
    );

    if (
      editingSkillId === id
    ) {
      setEditingSkillId(
        null,
      );
    }

    setSkillError("");
  };

  const handleSkillSearchChange = (
    skill: CandidateSkillItem,
    value: string,
  ) => {
    setSkillSearchValues(
      (current) => ({
        ...current,
        [skill.id]: value,
      }),
    );

    /*
     * Nếu Candidate đã chọn một skill
     * rồi nhưng bắt đầu nhập lại,
     * bỏ lựa chọn cũ để họ chọn lại
     * từ catalog hoặc dùng custom skill.
     */
    if (skill.skillCode) {
      onSkillsChange(
        skills.map((item) =>
          item.id === skill.id
            ? {
                ...item,

                skillCode: "",

                customSkillName: "",
              }
            : item,
        ),
      );
    }

    setSkillError("");
  };

  const selectCatalogSkill = (
    skillId: string,
    skillCode: string,
    skillName: string,
  ) => {
    onSkillsChange(
      skills.map((skill) =>
        skill.id === skillId
          ? {
              ...skill,

              skillCode,

              customSkillName: "",
            }
          : skill,
      ),
    );

    setSkillSearchValues(
      (current) => ({
        ...current,

        [skillId]: skillName,
      }),
    );

    setSkillError("");
  };

  const selectCustomSkill = (
    skillId: string,
    customSkillName: string,
  ) => {
    const normalizedName =
      customSkillName.trim();

    if (!normalizedName) {
      setSkillError(
        "Vui lòng nhập tên kỹ năng.",
      );

      return;
    }

    onSkillsChange(
      skills.map((skill) =>
        skill.id === skillId
          ? {
              ...skill,

              skillCode:
                OTHER_SKILL_CODE,

              customSkillName:
                normalizedName,
            }
          : skill,
      ),
    );

    setSkillSearchValues(
      (current) => ({
        ...current,

        [skillId]:
          normalizedName,
      }),
    );

    setSkillError("");
  };

  const skillExists = (
    skill: CandidateSkillItem,
  ) => {
    if (!skill.skillCode) {
      return false;
    }

    const identity =
      getSkillIdentity(
        skill.skillCode,
        skill.customSkillName,
      );

    return skills.some(
      (item) =>
        item.id !==
          skill.id &&
        Boolean(
          item.skillCode,
        ) &&
        getSkillIdentity(
          item.skillCode,
          item.customSkillName,
        ) === identity,
    );
  };

  const completeSkill = (
    skill: CandidateSkillItem,
  ) => {
    if (!skill.skillCode) {
      setSkillError(
        "Vui lòng chọn kỹ năng từ danh sách hoặc sử dụng kỹ năng khác.",
      );

      return;
    }

    if (
      skill.skillCode ===
        OTHER_SKILL_CODE &&
      !skill.customSkillName.trim()
    ) {
      setSkillError(
        "Vui lòng nhập tên kỹ năng.",
      );

      return;
    }

    if (
      skillExists(skill)
    ) {
      setSkillError(
        "Kỹ năng này đã tồn tại trong hồ sơ.",
      );

      return;
    }

    if (!skill.level) {
      setSkillError(
        "Vui lòng chọn mức độ kỹ năng.",
      );

      return;
    }

    if (
      skill.yearsOfExperience
    ) {
      const years = Number(
        skill.yearsOfExperience,
      );

      if (
        Number.isNaN(years) ||
        years < 0 ||
        years > 60
      ) {
        setSkillError(
          "Số năm kinh nghiệm không hợp lệ.",
        );

        return;
      }
    }

    setSkillSearchValues(
      (current) => ({
        ...current,

        [skill.id]:
          getSkillName(
            skill.skillCode,
            skill.customSkillName,
          ),
      }),
    );

    setSkillError("");

    setEditingSkillId(
      null,
    );
  };

  const editSkill = (
    skill: CandidateSkillItem,
  ) => {
    setEditingSkillId(
      skill.id,
    );

    setSkillSearchValues(
      (current) => ({
        ...current,

        [skill.id]:
          getSkillName(
            skill.skillCode,
            skill.customSkillName,
          ),
      }),
    );

    setSkillError("");
  };

  const toggleHighlighted = (
    skill: CandidateSkillItem,
  ) => {
    if (
      !skill.isHighlighted
    ) {
      const currentCount =
        skills.filter(
          (item) =>
            item.isHighlighted &&
            item.id !==
              skill.id,
        ).length;

      if (
        currentCount >= 5
      ) {
        setSkillError(
          "Bạn chỉ có thể chọn tối đa 5 kỹ năng nổi bật.",
        );

        return;
      }
    }

    setSkillError("");

    updateSkill(
      skill.id,
      "isHighlighted",
      !skill.isHighlighted,
    );
  };

  /* =======================================================
     LANGUAGES
  ======================================================= */

  const addLanguage = () => {
    const language =
      createLanguage();

    onLanguagesChange([
      ...languages,
      language,
    ]);

    setEditingLanguageId(
      language.id,
    );

    setEditingCertificate(
      null,
    );

    setLanguageError("");
    setCertificateError("");
  };

  const updateLanguage = <
    Key extends keyof CandidateLanguageItem,
  >(
    id: string,
    key: Key,
    value: CandidateLanguageItem[Key],
  ) => {
    onLanguagesChange(
      languages.map(
        (language) =>
          language.id === id
            ? {
                ...language,
                [key]: value,
              }
            : language,
      ),
    );
  };

  const handleLanguageCodeChange = (
    language: CandidateLanguageItem,
    languageCode: string,
  ) => {
    /*
     * Chứng chỉ gắn với ngôn ngữ.
     *
     * Khi đổi ngôn ngữ, xóa certificates
     * để tránh IELTS còn nằm trong
     * tiếng Nhật chẳng hạn.
     */
    onLanguagesChange(
      languages.map(
        (item) =>
          item.id ===
          language.id
            ? {
                ...item,

                languageCode,

                customLanguageName:
                  languageCode ===
                  "other"
                    ? item.customLanguageName
                    : "",

                certificates:
                  [],
              }
            : item,
      ),
    );

    setEditingCertificate(
      null,
    );

    setLanguageError("");
    setCertificateError("");
  };

  const removeLanguage = (
    id: string,
  ) => {
    onLanguagesChange(
      languages.filter(
        (language) =>
          language.id !== id,
      ),
    );

    if (
      editingLanguageId ===
      id
    ) {
      setEditingLanguageId(
        null,
      );
    }

    if (
      editingCertificate
        ?.languageId === id
    ) {
      setEditingCertificate(
        null,
      );
    }

    setLanguageError("");
    setCertificateError("");
  };

  const getLanguageIdentity = (
    language: CandidateLanguageItem,
  ) => {
    if (
      language.languageCode ===
      "other"
    ) {
      return language.customLanguageName
        .trim()
        .toLowerCase();
    }

    return language.languageCode
      .trim()
      .toLowerCase();
  };

  const languageExists = (
    language: CandidateLanguageItem,
  ) => {
    const identity =
      getLanguageIdentity(
        language,
      );

    if (!identity) {
      return false;
    }

    return languages.some(
      (item) =>
        item.id !==
          language.id &&
        getLanguageIdentity(
          item,
        ) === identity,
    );
  };

  const completeLanguage = (
    language: CandidateLanguageItem,
  ) => {
    if (
      !language.languageCode
    ) {
      setLanguageError(
        "Vui lòng chọn ngôn ngữ.",
      );

      return;
    }

    if (
      language.languageCode ===
        "other" &&
      !language.customLanguageName.trim()
    ) {
      setLanguageError(
        "Vui lòng nhập tên ngôn ngữ.",
      );

      return;
    }

    if (
      !language.overallLevel
    ) {
      setLanguageError(
        "Vui lòng chọn trình độ tổng quát.",
      );

      return;
    }

    if (
      languageExists(language)
    ) {
      setLanguageError(
        "Ngôn ngữ này đã tồn tại trong hồ sơ.",
      );

      return;
    }

    setLanguageError("");
    setCertificateError("");

    setEditingCertificate(
      null,
    );

    setEditingLanguageId(
      null,
    );
  };

  /* =======================================================
     CERTIFICATES
  ======================================================= */

  const addCertificate = (
    languageId: string,
  ) => {
    const certificate =
      createCertificate();

    onLanguagesChange(
      languages.map(
        (language) =>
          language.id ===
          languageId
            ? {
                ...language,

                certificates: [
                  ...language.certificates,
                  certificate,
                ],
              }
            : language,
      ),
    );

    setEditingCertificate({
      languageId,
      certificateId:
        certificate.id,
    });

    setCertificateError("");
  };

  const updateCertificate = <
    Key extends keyof LanguageCertificateItem,
  >(
    languageId: string,
    certificateId: string,
    key: Key,
    value: LanguageCertificateItem[Key],
  ) => {
    onLanguagesChange(
      languages.map(
        (language) =>
          language.id ===
          languageId
            ? {
                ...language,

                certificates:
                  language.certificates.map(
                    (
                      certificate,
                    ) =>
                      certificate.id ===
                      certificateId
                        ? {
                            ...certificate,
                            [key]:
                              value,
                          }
                        : certificate,
                  ),
              }
            : language,
      ),
    );
  };

  const removeCertificate = (
    languageId: string,
    certificateId: string,
  ) => {
    onLanguagesChange(
      languages.map(
        (language) =>
          language.id ===
          languageId
            ? {
                ...language,

                certificates:
                  language.certificates.filter(
                    (
                      certificate,
                    ) =>
                      certificate.id !==
                      certificateId,
                  ),
              }
            : language,
      ),
    );

    if (
      editingCertificate
        ?.languageId ===
        languageId &&
      editingCertificate
        .certificateId ===
        certificateId
    ) {
      setEditingCertificate(
        null,
      );
    }

    setCertificateError("");
  };

  const handleCertificateTypeChange = (
    languageId: string,
    certificate: LanguageCertificateItem,
    certificateTypeCode: string,
  ) => {
    const definition =
      getCertificateTypeByCode(
        certificateTypeCode,
      );

    const oldScores =
      new Map(
        certificate.scores.map(
          (score) => [
            score.componentCode,
            score.value,
          ],
        ),
      );

    const scores: LanguageCertificateScoreItem[] =
      definition
        ? definition.scoreFields.map(
            (field) => ({
              id: crypto.randomUUID(),

              componentCode:
                field.code,

              value:
                oldScores.get(
                  field.code,
                ) ?? "",
            }),
          )
        : [];

    const updatedCertificate: LanguageCertificateItem =
      {
        ...certificate,

        certificateTypeCode,

        customCertificateName:
          certificateTypeCode ===
          "other"
            ? certificate.customCertificateName
            : "",

        level:
          definition?.supportsLevel
            ? certificate.level
            : "",

        overallScore:
          definition?.supportsOverallScore ||
          certificateTypeCode ===
            "other"
            ? certificate.overallScore
            : "",

        scores,
      };

    onLanguagesChange(
      languages.map(
        (language) =>
          language.id ===
          languageId
            ? {
                ...language,

                certificates:
                  language.certificates.map(
                    (item) =>
                      item.id ===
                      certificate.id
                        ? updatedCertificate
                        : item,
                  ),
              }
            : language,
      ),
    );

    setCertificateError("");
  };

  const updateCertificateScore = (
    languageId: string,
    certificateId: string,
    componentCode: string,
    value: string,
  ) => {
    onLanguagesChange(
      languages.map(
        (language) =>
          language.id ===
          languageId
            ? {
                ...language,

                certificates:
                  language.certificates.map(
                    (
                      certificate,
                    ) =>
                      certificate.id ===
                      certificateId
                        ? {
                            ...certificate,

                            scores:
                              certificate.scores.map(
                                (
                                  score,
                                ) =>
                                  score.componentCode ===
                                  componentCode
                                    ? {
                                        ...score,
                                        value,
                                      }
                                    : score,
                              ),
                          }
                        : certificate,
                  ),
              }
            : language,
      ),
    );
  };

  const completeCertificate = (
    certificate: LanguageCertificateItem,
  ) => {
    if (
      !certificate.certificateTypeCode
    ) {
      setCertificateError(
        "Vui lòng chọn loại chứng chỉ.",
      );

      return;
    }

    if (
      certificate.certificateTypeCode ===
        "other" &&
      !certificate.customCertificateName.trim()
    ) {
      setCertificateError(
        "Vui lòng nhập tên chứng chỉ.",
      );

      return;
    }

    const definition =
      getCertificateTypeByCode(
        certificate.certificateTypeCode,
      );

    if (
      definition?.supportsLevel &&
      definition.levelOptions &&
      definition.levelOptions.length >
        0 &&
      !certificate.level
    ) {
      setCertificateError(
        "Vui lòng chọn cấp độ của chứng chỉ.",
      );

      return;
    }

    if (
      certificate.issuedDate &&
      certificate.expiryDate &&
      certificate.expiryDate <
        certificate.issuedDate
    ) {
      setCertificateError(
        "Ngày hết hạn không thể trước ngày cấp.",
      );

      return;
    }

    setCertificateError("");

    setEditingCertificate(
      null,
    );
  };

  /* =======================================================
     RENDER
  ======================================================= */

  return (
    <div
      className={
        styles.wrapper
      }
    >
      {/* ===================================================
          SKILLS
      =================================================== */}

      <section>
        <div
          className={
            styles.sectionIntro
          }
        >
          <div>
            <span
              className={
                styles.eyebrow
              }
            >
              KỸ NĂNG
            </span>

            <h3>
              Năng lực nghề nghiệp
            </h3>

            <p>
              Tìm và chọn kỹ năng từ
              danh mục chuẩn. Nếu kỹ
              năng của bạn chưa có,
              bạn vẫn có thể thêm kỹ
              năng khác.
            </p>
          </div>

          {skills.length > 0 && (
            <button
              type="button"
              className={
                styles.addButton
              }
              onClick={addSkill}
            >
              <span>+</span>

              Thêm kỹ năng
            </button>
          )}
        </div>

        {skills.length === 0 ? (
          <div
            className={
              styles.emptyState
            }
          >
            <div
              className={
                styles.emptyIcon
              }
            >
              <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  d="M12 3 14.3 8.1 20 9l-4.1 4 1 5.7L12 16l-4.9 2.7 1-5.7L4 9l5.7-.9L12 3Z"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinejoin="round"
                />
              </svg>
            </div>

            <h4>
              Chưa có kỹ năng
            </h4>

            <p>
              Thêm kỹ năng chuyên môn,
              công cụ và kỹ năng mềm
              phản ánh đúng năng lực
              của bạn.
            </p>

            <button
              type="button"
              onClick={addSkill}
            >
              + Thêm kỹ năng đầu tiên
            </button>
          </div>
        ) : (
          <div
            className={
              styles.itemList
            }
          >
            {skills.map(
              (
                skill,
                index,
              ) => {
                const isEditing =
                  editingSkillId ===
                  skill.id;

                const skillName =
                  getSkillName(
                    skill.skillCode,
                    skill.customSkillName,
                  );

                const categoryName =
                  getSkillCategoryName(
                    skill.skillCode,
                  );

                const searchValue =
                  skillSearchValues[
                    skill.id
                  ] ??
                  (skill.skillCode
                    ? skillName
                    : "");

                const suggestions =
                  !skill.skillCode
                    ? searchSkills(
                        searchValue,
                        8,
                      )
                    : [];

                return (
                  <article
                    key={
                      skill.id
                    }
                    className={
                      styles.itemCard
                    }
                  >
                    <div
                      className={
                        styles.cardHeader
                      }
                    >
                      <div>
                        <span
                          className={
                            styles.itemNumber
                          }
                        >
                          KỸ NĂNG{" "}
                          {index + 1}
                        </span>

                        <h4>
                          {skill.skillCode
                            ? skillName
                            : "Kỹ năng mới"}
                        </h4>

                        {!isEditing && (
                          <div
                            className={
                              styles.summary
                            }
                          >
                            <p>
                              {categoryName ||
                                (skill.skillCode ===
                                OTHER_SKILL_CODE
                                  ? "Kỹ năng tùy chỉnh"
                                  : "Chưa phân loại")}
                              {" · "}
                              {getSkillLevelLabel(
                                skill.level,
                              )}
                            </p>

                            {skill.yearsOfExperience && (
                              <span>
                                {
                                  skill.yearsOfExperience
                                }{" "}
                                năm kinh nghiệm
                              </span>
                            )}

                            {skill.isHighlighted && (
                              <span
                                className={
                                  styles.highlightBadge
                                }
                              >
                                ★ Kỹ năng nổi bật
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      <div
                        className={
                          styles.cardActions
                        }
                      >
                        {!isEditing && (
                          <button
                            type="button"
                            className={
                              styles.editButton
                            }
                            onClick={() =>
                              editSkill(
                                skill,
                              )
                            }
                          >
                            Sửa
                          </button>
                        )}

                        <button
                          type="button"
                          className={
                            styles.removeButton
                          }
                          onClick={() =>
                            removeSkill(
                              skill.id,
                            )
                          }
                        >
                          Xóa
                        </button>
                      </div>
                    </div>

                    {isEditing && (
                      <div
                        className={
                          styles.editArea
                        }
                      >
                        <div
                          className={
                            styles.grid
                          }
                        >
                          {/* ===========================
                              SKILL SEARCH
                          =========================== */}

                          <div
                            className={`${styles.field} ${styles.fullWidth}`}
                          >
                            <label>
                              Kỹ năng

                              <span>
                                *
                              </span>
                            </label>

                            <div
                              className={
                                styles.skillPicker
                              }
                            >
                              <input
                                type="text"
                                autoComplete="off"
                                value={
                                  searchValue
                                }
                                placeholder="Tìm JavaScript, Excel, Sales, AutoCAD..."
                                onChange={(
                                  event,
                                ) =>
                                  handleSkillSearchChange(
                                    skill,
                                    event
                                      .target
                                      .value,
                                  )
                                }
                              />

                              {!skill.skillCode && (
                                <div
                                  className={
                                    styles.skillSuggestions
                                  }
                                >
                                  {suggestions.length >
                                  0 ? (
                                    suggestions.map(
                                      (
                                        option,
                                      ) => (
                                        <button
                                          key={
                                            option.code
                                          }
                                          type="button"
                                          className={
                                            styles.skillSuggestion
                                          }
                                          onClick={() =>
                                            selectCatalogSkill(
                                              skill.id,
                                              option.code,
                                              option.name,
                                            )
                                          }
                                        >
                                          <span>
                                            {
                                              option.name
                                            }
                                          </span>

                                          <small>
                                            {getSkillCategoryName(
                                              option.code,
                                            )}
                                          </small>
                                        </button>
                                      ),
                                    )
                                  ) : (
                                    <div
                                      className={
                                        styles.skillNoResult
                                      }
                                    >
                                      Không tìm thấy kỹ năng
                                      phù hợp trong danh mục.
                                    </div>
                                  )}

                                  {searchValue.trim() && (
                                    <button
                                      type="button"
                                      className={
                                        styles.customSkillOption
                                      }
                                      onClick={() =>
                                        selectCustomSkill(
                                          skill.id,
                                          searchValue,
                                        )
                                      }
                                    >
                                      <span>
                                        + Dùng “
                                        {
                                          searchValue.trim()
                                        }
                                        ” làm kỹ năng khác
                                      </span>

                                      <small>
                                        Chỉ sử dụng khi
                                        không tìm thấy kỹ
                                        năng phù hợp trong
                                        danh mục chuẩn.
                                      </small>
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>

                            {skill.skillCode && (
                              <div
                                className={
                                  styles.selectedSkillMeta
                                }
                              >
                                <div>
                                  <strong>
                                    Đã chọn:{" "}
                                    {
                                      skillName
                                    }
                                  </strong>

                                  <span>
                                    {categoryName ||
                                      "Kỹ năng tùy chỉnh"}
                                  </span>
                                </div>

                                <button
                                  type="button"
                                  className={
                                    styles.changeSkillButton
                                  }
                                  onClick={() =>
                                    handleSkillSearchChange(
                                      skill,
                                      "",
                                    )
                                  }
                                >
                                  Chọn lại
                                </button>
                              </div>
                            )}

                            <small>
                              Gõ tên kỹ năng để
                              tìm trong danh mục.
                              Có thể tìm bằng tên
                              hoặc tên gọi khác
                              như JS, Excel,
                              CSKH...
                            </small>
                          </div>

                          {/* ===========================
                              LEVEL
                          =========================== */}

                          <div
                            className={
                              styles.field
                            }
                          >
                            <label>
                              Mức độ

                              <span>
                                *
                              </span>
                            </label>

                            <select
                              value={
                                skill.level
                              }
                              onChange={(
                                event,
                              ) =>
                                updateSkill(
                                  skill.id,
                                  "level",
                                  event
                                    .target
                                    .value as CandidateSkillItem["level"],
                                )
                              }
                            >
                              <option value="">
                                Chọn mức độ
                              </option>

                              <option value="beginner">
                                Cơ bản
                              </option>

                              <option value="intermediate">
                                Trung bình
                              </option>

                              <option value="advanced">
                                Khá
                              </option>

                              <option value="proficient">
                                Thành thạo
                              </option>

                              <option value="expert">
                                Chuyên gia
                              </option>
                            </select>
                          </div>

                          {/* ===========================
                              YEARS
                          =========================== */}

                          <div
                            className={
                              styles.field
                            }
                          >
                            <label>
                              Số năm kinh nghiệm
                            </label>

                            <input
                              type="number"
                              min="0"
                              max="60"
                              step="0.5"
                              value={
                                skill.yearsOfExperience
                              }
                              placeholder="Ví dụ: 2"
                              onChange={(
                                event,
                              ) =>
                                updateSkill(
                                  skill.id,
                                  "yearsOfExperience",
                                  event
                                    .target
                                    .value,
                                )
                              }
                            />

                            <small>
                              Có thể nhập số lẻ,
                              ví dụ 0.5 hoặc 1.5
                              năm.
                            </small>
                          </div>
                        </div>

                        {/* ===========================
                            HIGHLIGHT
                        =========================== */}

                        <label
                          className={
                            styles.checkboxRow
                          }
                        >
                          <input
                            type="checkbox"
                            checked={
                              skill.isHighlighted
                            }
                            onChange={() =>
                              toggleHighlighted(
                                skill,
                              )
                            }
                          />

                          <span>
                            Đánh dấu đây là kỹ
                            năng nổi bật
                          </span>
                        </label>

                        <small
                          className={
                            styles.helperText
                          }
                        >
                          Có thể chọn tối đa 5
                          kỹ năng nổi bật để
                          ưu tiên hiển thị
                          trong hồ sơ.
                        </small>

                        {/* ===========================
                            ERROR
                        =========================== */}

                        {skillError && (
                          <div
                            className={
                              styles.validationNotice
                            }
                          >
                            {
                              skillError
                            }
                          </div>
                        )}

                        {/* ===========================
                            ACTION
                        =========================== */}

                        <div
                          className={
                            styles.editActions
                          }
                        >
                          <button
                            type="button"
                            className={
                              styles.doneButton
                            }
                            onClick={() =>
                              completeSkill(
                                skill,
                              )
                            }
                          >
                            Hoàn tất kỹ năng
                          </button>
                        </div>
                      </div>
                    )}
                  </article>
                );
              },
            )}

            <button
              type="button"
              className={
                styles.addAnotherButton
              }
              onClick={
                addSkill
              }
            >
              <span>
                +
              </span>

              Thêm kỹ năng khác
            </button>
          </div>
        )}
      </section>

      <div
        className={
          styles.mainDivider
        }
      />

      {/* ===================================================
          LANGUAGES
      =================================================== */}

      <section>
        <div
          className={
            styles.sectionIntro
          }
        >
          <div>
            <span
              className={
                styles.eyebrow
              }
            >
              NGÔN NGỮ
            </span>

            <h3>
              Khả năng ngôn ngữ
            </h3>

            <p>
              Thêm ngôn ngữ bạn
              có thể sử dụng, trình
              độ thực tế và các
              chứng chỉ liên quan
              nếu có.
            </p>
          </div>

          {languages.length >
            0 && (
            <button
              type="button"
              className={
                styles.addButton
              }
              onClick={
                addLanguage
              }
            >
              <span>+</span>

              Thêm ngôn ngữ
            </button>
          )}
        </div>

        {languages.length ===
        0 ? (
          <div
            className={
              styles.emptyState
            }
          >
            <div
              className={
                styles.emptyIcon
              }
            >
              <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  d="M5 5h9M9.5 3v2c0 4-2.4 7.4-6 9M6 9c1.5 2.2 3.5 4 6 5M14 20l3.5-8 3.5 8M15.4 17h4.2"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>

            <h4>
              Chưa có ngôn ngữ
            </h4>

            <p>
              Chọn ngôn ngữ từ
              danh sách chuẩn hoặc
              chọn Khác nếu ngôn
              ngữ bạn sử dụng chưa
              có trong danh mục.
            </p>

            <button
              type="button"
              onClick={
                addLanguage
              }
            >
              + Thêm ngôn ngữ đầu tiên
            </button>
          </div>
        ) : (
          <div
            className={
              styles.itemList
            }
          >
            {languages.map(
              (
                language,
                index,
              ) => {
                const isEditing =
                  editingLanguageId ===
                  language.id;

                const certificateTypes =
                  getCertificateTypesForLanguage(
                    language.languageCode,
                  );

                return (
                  <article
                    key={
                      language.id
                    }
                    className={
                      styles.itemCard
                    }
                  >
                    <div
                      className={
                        styles.cardHeader
                      }
                    >
                      <div>
                        <span
                          className={
                            styles.itemNumber
                          }
                        >
                          NGÔN NGỮ{" "}
                          {index + 1}
                        </span>

                        <h4>
                          {getLanguageLabel(
                            language.languageCode,
                            language.customLanguageName,
                          )}
                        </h4>

                        {!isEditing && (
                          <div
                            className={
                              styles.summary
                            }
                          >
                            <p>
                              {getLanguageLevelLabel(
                                language.overallLevel,
                              )}
                            </p>

                            <span>
                              {
                                language
                                  .certificates
                                  .length
                              }{" "}
                              chứng chỉ
                            </span>
                          </div>
                        )}
                      </div>

                      <div
                        className={
                          styles.cardActions
                        }
                      >
                        {!isEditing && (
                          <button
                            type="button"
                            className={
                              styles.editButton
                            }
                            onClick={() => {
                              setEditingLanguageId(
                                language.id,
                              );

                              setLanguageError(
                                "",
                              );

                              setCertificateError(
                                "",
                              );
                            }}
                          >
                            Sửa
                          </button>
                        )}

                        <button
                          type="button"
                          className={
                            styles.removeButton
                          }
                          onClick={() =>
                            removeLanguage(
                              language.id,
                            )
                          }
                        >
                          Xóa
                        </button>
                      </div>
                    </div>

                    {isEditing && (
                      <div
                        className={
                          styles.editArea
                        }
                      >
                        {/* LANGUAGE */}

                        <div
                          className={
                            styles.sectionTitle
                          }
                        >
                          <span>
                            THÔNG TIN NGÔN NGỮ
                          </span>

                          <h5>
                            Ngôn ngữ & trình độ
                          </h5>
                        </div>

                        <div
                          className={
                            styles.grid
                          }
                        >
                          <div
                            className={
                              styles.field
                            }
                          >
                            <label>
                              Ngôn ngữ
                              <span>
                                *
                              </span>
                            </label>

                            <select
                              value={
                                language.languageCode
                              }
                              onChange={(
                                event,
                              ) =>
                                handleLanguageCodeChange(
                                  language,
                                  event
                                    .target
                                    .value,
                                )
                              }
                            >
                              <option value="">
                                Chọn ngôn ngữ
                              </option>

                              {LANGUAGE_OPTIONS.map(
                                (
                                  option,
                                ) => (
                                  <option
                                    key={
                                      option.code
                                    }
                                    value={
                                      option.code
                                    }
                                  >
                                    {option.label}
                                  </option>
                                ),
                              )}
                            </select>

                            <small>
                              Nếu không
                              tìm thấy,
                              chọn
                              “Khác...”.
                            </small>
                          </div>

                          {language.languageCode ===
                            "other" && (
                            <div
                              className={
                                styles.field
                              }
                            >
                              <label>
                                Tên ngôn ngữ
                                <span>
                                  *
                                </span>
                              </label>

                              <input
                                type="text"
                                value={
                                  language.customLanguageName
                                }
                                placeholder="Ví dụ: Tiếng Ba Tư"
                                onChange={(
                                  event,
                                ) =>
                                  updateLanguage(
                                    language.id,
                                    "customLanguageName",
                                    event
                                      .target
                                      .value,
                                  )
                                }
                              />
                            </div>
                          )}

                          <div
                            className={
                              styles.field
                            }
                          >
                            <label>
                              Trình độ tổng quát
                              <span>
                                *
                              </span>
                            </label>

                            <select
                              value={
                                language.overallLevel
                              }
                              onChange={(
                                event,
                              ) =>
                                updateLanguage(
                                  language.id,
                                  "overallLevel",
                                  event
                                    .target
                                    .value as LanguageProficiency,
                                )
                              }
                            >
                              <LanguageOptions />
                            </select>
                          </div>
                        </div>

                        <div
                          className={
                            styles.sectionDivider
                          }
                        />

                        {/* PROFICIENCY */}

                        <div
                          className={
                            styles.sectionTitle
                          }
                        >
                          <span>
                            KỸ NĂNG NGÔN NGỮ
                          </span>

                          <h5>
                            Nghe · Nói · Đọc · Viết
                          </h5>
                        </div>

                        <div
                          className={
                            styles.languageSkillsGrid
                          }
                        >
                          <LanguageLevelField
                            label="Nghe"
                            value={
                              language.listeningLevel
                            }
                            onChange={(
                              value,
                            ) =>
                              updateLanguage(
                                language.id,
                                "listeningLevel",
                                value,
                              )
                            }
                          />

                          <LanguageLevelField
                            label="Nói"
                            value={
                              language.speakingLevel
                            }
                            onChange={(
                              value,
                            ) =>
                              updateLanguage(
                                language.id,
                                "speakingLevel",
                                value,
                              )
                            }
                          />

                          <LanguageLevelField
                            label="Đọc"
                            value={
                              language.readingLevel
                            }
                            onChange={(
                              value,
                            ) =>
                              updateLanguage(
                                language.id,
                                "readingLevel",
                                value,
                              )
                            }
                          />

                          <LanguageLevelField
                            label="Viết"
                            value={
                              language.writingLevel
                            }
                            onChange={(
                              value,
                            ) =>
                              updateLanguage(
                                language.id,
                                "writingLevel",
                                value,
                              )
                            }
                          />
                        </div>

                        <div
                          className={
                            styles.sectionDivider
                          }
                        />

                        {/* CERTIFICATES */}

                        <div
                          className={
                            styles.certificateHeader
                          }
                        >
                          <div
                            className={
                              styles.sectionTitle
                            }
                          >
                            <span>
                              CHỨNG CHỈ
                            </span>

                            <h5>
                              Chứng chỉ ngôn ngữ
                            </h5>
                          </div>

                          {language.languageCode && (
                            <button
                              type="button"
                              className={
                                styles.addCertificateButton
                              }
                              onClick={() =>
                                addCertificate(
                                  language.id,
                                )
                              }
                            >
                              + Thêm chứng chỉ
                            </button>
                          )}
                        </div>

                        {!language.languageCode ? (
                          <div
                            className={
                              styles.certificateEmpty
                            }
                          >
                            Chọn ngôn ngữ
                            trước để thêm
                            chứng chỉ phù
                            hợp.
                          </div>
                        ) : language
                            .certificates
                            .length ===
                          0 ? (
                          <div
                            className={
                              styles.certificateEmpty
                            }
                          >
                            Không bắt buộc
                            phải có chứng
                            chỉ. Nếu có,
                            bạn có thể
                            thêm nhiều
                            chứng chỉ cho
                            cùng một ngôn
                            ngữ.
                          </div>
                        ) : (
                          <div
                            className={
                              styles.certificateList
                            }
                          >
                            {language.certificates.map(
                              (
                                certificate,
                              ) => {
                                const isCertificateEditing =
                                  editingCertificate
                                    ?.languageId ===
                                    language.id &&
                                  editingCertificate
                                    ?.certificateId ===
                                    certificate.id;

                                const definition =
                                  getCertificateTypeByCode(
                                    certificate.certificateTypeCode,
                                  );

                                return (
                                  <div
                                    key={
                                      certificate.id
                                    }
                                    className={
                                      styles.certificateCard
                                    }
                                  >
                                    <div
                                      className={
                                        styles.certificateCardHeader
                                      }
                                    >
                                      <div>
                                        <strong>
                                          {getCertificateLabel(
                                            certificate.certificateTypeCode,
                                            certificate.customCertificateName,
                                          )}
                                        </strong>

                                        {!isCertificateEditing && (
                                          <div
                                            className={
                                              styles.certificateSummary
                                            }
                                          >
                                            {certificate.level && (
                                              <span>
                                                Cấp độ:{" "}
                                                {
                                                  certificate.level
                                                }
                                              </span>
                                            )}

                                            {certificate.overallScore && (
                                              <span>
                                                Điểm:{" "}
                                                {
                                                  certificate.overallScore
                                                }
                                              </span>
                                            )}

                                            {certificate.scores
                                              .filter(
                                                (
                                                  score,
                                                ) =>
                                                  score.value,
                                              )
                                              .map(
                                                (
                                                  score,
                                                ) => {
                                                  const field =
                                                    definition?.scoreFields.find(
                                                      (
                                                        item,
                                                      ) =>
                                                        item.code ===
                                                        score.componentCode,
                                                    );

                                                  return (
                                                    <span
                                                      key={
                                                        score.id
                                                      }
                                                    >
                                                      {field?.label ??
                                                        score.componentCode}
                                                      :{" "}
                                                      {
                                                        score.value
                                                      }
                                                    </span>
                                                  );
                                                },
                                              )}
                                          </div>
                                        )}
                                      </div>

                                      <div
                                        className={
                                          styles.cardActions
                                        }
                                      >
                                        {!isCertificateEditing && (
                                          <button
                                            type="button"
                                            className={
                                              styles.editButton
                                            }
                                            onClick={() => {
                                              setEditingCertificate(
                                                {
                                                  languageId:
                                                    language.id,
                                                  certificateId:
                                                    certificate.id,
                                                },
                                              );

                                              setCertificateError(
                                                "",
                                              );
                                            }}
                                          >
                                            Sửa
                                          </button>
                                        )}

                                        <button
                                          type="button"
                                          className={
                                            styles.removeButton
                                          }
                                          onClick={() =>
                                            removeCertificate(
                                              language.id,
                                              certificate.id,
                                            )
                                          }
                                        >
                                          Xóa
                                        </button>
                                      </div>
                                    </div>

                                    {isCertificateEditing && (
                                      <div
                                        className={
                                          styles.certificateForm
                                        }
                                      >
                                        <div
                                          className={
                                            styles.grid
                                          }
                                        >
                                          <div
                                            className={
                                              styles.field
                                            }
                                          >
                                            <label>
                                              Loại chứng chỉ
                                              <span>
                                                *
                                              </span>
                                            </label>

                                            <select
                                              value={
                                                certificate.certificateTypeCode
                                              }
                                              onChange={(
                                                event,
                                              ) =>
                                                handleCertificateTypeChange(
                                                  language.id,
                                                  certificate,
                                                  event
                                                    .target
                                                    .value,
                                                )
                                              }
                                            >
                                              <option value="">
                                                Chọn chứng chỉ
                                              </option>

                                              {certificateTypes.map(
                                                (
                                                  type,
                                                ) => (
                                                  <option
                                                    key={
                                                      type.code
                                                    }
                                                    value={
                                                      type.code
                                                    }
                                                  >
                                                    {
                                                      type.label
                                                    }
                                                  </option>
                                                ),
                                              )}

                                              <option value="other">
                                                Khác...
                                              </option>
                                            </select>
                                          </div>

                                          {certificate.certificateTypeCode ===
                                            "other" && (
                                            <div
                                              className={
                                                styles.field
                                              }
                                            >
                                              <label>
                                                Tên chứng chỉ
                                                <span>
                                                  *
                                                </span>
                                              </label>

                                              <input
                                                type="text"
                                                value={
                                                  certificate.customCertificateName
                                                }
                                                placeholder="Nhập tên chứng chỉ"
                                                onChange={(
                                                  event,
                                                ) =>
                                                  updateCertificate(
                                                    language.id,
                                                    certificate.id,
                                                    "customCertificateName",
                                                    event
                                                      .target
                                                      .value,
                                                  )
                                                }
                                              />
                                            </div>
                                          )}
                                        </div>

                                        {certificate.certificateTypeCode && (
                                          <>
                                            <div
                                              className={
                                                styles.certificateScoreSection
                                              }
                                            >
                                              {(definition?.supportsLevel ||
                                                certificate.certificateTypeCode ===
                                                  "other") && (
                                                <div
                                                  className={
                                                    styles.field
                                                  }
                                                >
                                                  <label>
                                                    Cấp độ
                                                  </label>

                                                  {definition
                                                    ?.levelOptions &&
                                                  definition
                                                    .levelOptions
                                                    .length >
                                                    0 ? (
                                                    <select
                                                      value={
                                                        certificate.level
                                                      }
                                                      onChange={(
                                                        event,
                                                      ) =>
                                                        updateCertificate(
                                                          language.id,
                                                          certificate.id,
                                                          "level",
                                                          event
                                                            .target
                                                            .value,
                                                        )
                                                      }
                                                    >
                                                      <option value="">
                                                        Chọn cấp độ
                                                      </option>

                                                      {definition.levelOptions.map(
                                                        (
                                                          level,
                                                        ) => (
                                                          <option
                                                            key={
                                                              level
                                                            }
                                                            value={
                                                              level
                                                            }
                                                          >
                                                            {
                                                              level
                                                            }
                                                          </option>
                                                        ),
                                                      )}
                                                    </select>
                                                  ) : (
                                                    <input
                                                      type="text"
                                                      value={
                                                        certificate.level
                                                      }
                                                      placeholder="Ví dụ: B2, N3, Level 4..."
                                                      onChange={(
                                                        event,
                                                      ) =>
                                                        updateCertificate(
                                                          language.id,
                                                          certificate.id,
                                                          "level",
                                                          event
                                                            .target
                                                            .value,
                                                        )
                                                      }
                                                    />
                                                  )}
                                                </div>
                                              )}

                                              {(definition?.supportsOverallScore ||
                                                certificate.certificateTypeCode ===
                                                  "other") && (
                                                <div
                                                  className={
                                                    styles.field
                                                  }
                                                >
                                                  <label>
                                                    Điểm tổng /
                                                    Overall
                                                  </label>

                                                  <input
                                                    type="text"
                                                    value={
                                                      certificate.overallScore
                                                    }
                                                    placeholder="Ví dụ: 850, 6.5, 95..."
                                                    onChange={(
                                                      event,
                                                    ) =>
                                                      updateCertificate(
                                                        language.id,
                                                        certificate.id,
                                                        "overallScore",
                                                        event
                                                          .target
                                                          .value,
                                                      )
                                                    }
                                                  />
                                                </div>
                                              )}
                                            </div>

                                            {definition &&
                                              definition
                                                .scoreFields
                                                .length >
                                                0 && (
                                                <>
                                                  <div
                                                    className={
                                                      styles.scoreHeading
                                                    }
                                                  >
                                                    Điểm thành phần
                                                  </div>

                                                  <div
                                                    className={
                                                      styles.languageSkillsGrid
                                                    }
                                                  >
                                                    {definition.scoreFields.map(
                                                      (
                                                        field,
                                                      ) => {
                                                        const score =
                                                          certificate.scores.find(
                                                            (
                                                              item,
                                                            ) =>
                                                              item.componentCode ===
                                                              field.code,
                                                          );

                                                        return (
                                                          <div
                                                            key={
                                                              field.code
                                                            }
                                                            className={
                                                              styles.field
                                                            }
                                                          >
                                                            <label>
                                                              {
                                                                field.label
                                                              }
                                                            </label>

                                                            <input
                                                              type="number"
                                                              min={
                                                                field.min
                                                              }
                                                              max={
                                                                field.max
                                                              }
                                                              step={
                                                                field.step
                                                              }
                                                              value={
                                                                score?.value ??
                                                                ""
                                                              }
                                                              placeholder="Điểm"
                                                              onChange={(
                                                                event,
                                                              ) =>
                                                                updateCertificateScore(
                                                                  language.id,
                                                                  certificate.id,
                                                                  field.code,
                                                                  event
                                                                    .target
                                                                    .value,
                                                                )
                                                              }
                                                            />
                                                          </div>
                                                        );
                                                      },
                                                    )}
                                                  </div>
                                                </>
                                              )}
                                          </>
                                        )}

                                        <div
                                          className={
                                            styles.sectionDivider
                                          }
                                        />

                                        <div
                                          className={
                                            styles.grid
                                          }
                                        >
                                          <div
                                            className={
                                              styles.field
                                            }
                                          >
                                            <label>
                                              Ngày cấp /
                                              Ngày thi
                                            </label>

                                            <input
                                              type="date"
                                              value={
                                                certificate.issuedDate
                                              }
                                              onChange={(
                                                event,
                                              ) =>
                                                updateCertificate(
                                                  language.id,
                                                  certificate.id,
                                                  "issuedDate",
                                                  event
                                                    .target
                                                    .value,
                                                )
                                              }
                                            />
                                          </div>

                                          <div
                                            className={
                                              styles.field
                                            }
                                          >
                                            <label>
                                              Ngày hết hạn
                                            </label>

                                            <input
                                              type="date"
                                              value={
                                                certificate.expiryDate
                                              }
                                              onChange={(
                                                event,
                                              ) =>
                                                updateCertificate(
                                                  language.id,
                                                  certificate.id,
                                                  "expiryDate",
                                                  event
                                                    .target
                                                    .value,
                                                )
                                              }
                                            />

                                            <small>
                                              Để trống nếu
                                              không áp dụng.
                                            </small>
                                          </div>

                                          <div
                                            className={
                                              styles.field
                                            }
                                          >
                                            <label>
                                              Đơn vị cấp
                                            </label>

                                            <input
                                              type="text"
                                              value={
                                                certificate.issuer
                                              }
                                              placeholder="Ví dụ: ETS, British Council..."
                                              onChange={(
                                                event,
                                              ) =>
                                                updateCertificate(
                                                  language.id,
                                                  certificate.id,
                                                  "issuer",
                                                  event
                                                    .target
                                                    .value,
                                                )
                                              }
                                            />
                                          </div>

                                          <div
                                            className={
                                              styles.field
                                            }
                                          >
                                            <label>
                                              Mã chứng chỉ
                                            </label>

                                            <input
                                              type="text"
                                              value={
                                                certificate.credentialId
                                              }
                                              placeholder="Credential ID"
                                              onChange={(
                                                event,
                                              ) =>
                                                updateCertificate(
                                                  language.id,
                                                  certificate.id,
                                                  "credentialId",
                                                  event
                                                    .target
                                                    .value,
                                                )
                                              }
                                            />
                                          </div>

                                          <div
                                            className={`${styles.field} ${styles.fullWidth}`}
                                          >
                                            <label>
                                              Link xác minh
                                            </label>

                                            <input
                                              type="url"
                                              value={
                                                certificate.verificationUrl
                                              }
                                              placeholder="https://..."
                                              onChange={(
                                                event,
                                              ) =>
                                                updateCertificate(
                                                  language.id,
                                                  certificate.id,
                                                  "verificationUrl",
                                                  event
                                                    .target
                                                    .value,
                                                )
                                              }
                                            />
                                          </div>
                                        </div>

                                        {certificateError && (
                                          <div
                                            className={
                                              styles.validationNotice
                                            }
                                          >
                                            {
                                              certificateError
                                            }
                                          </div>
                                        )}

                                        <div
                                          className={
                                            styles.editActions
                                          }
                                        >
                                          <button
                                            type="button"
                                            className={
                                              styles.doneButton
                                            }
                                            onClick={() =>
                                              completeCertificate(
                                                certificate,
                                              )
                                            }
                                          >
                                            Hoàn tất chứng chỉ
                                          </button>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              },
                            )}
                          </div>
                        )}

                        {languageError && (
                          <div
                            className={
                              styles.validationNotice
                            }
                          >
                            {languageError}
                          </div>
                        )}

                        <div
                          className={
                            styles.editActions
                          }
                        >
                          <button
                            type="button"
                            className={
                              styles.doneButton
                            }
                            onClick={() =>
                              completeLanguage(
                                language,
                              )
                            }
                          >
                            Hoàn tất ngôn ngữ
                          </button>
                        </div>
                      </div>
                    )}
                  </article>
                );
              },
            )}

            <button
              type="button"
              className={
                styles.addAnotherButton
              }
              onClick={
                addLanguage
              }
            >
              <span>+</span>

              Thêm ngôn ngữ khác
            </button>
          </div>
        )}
      </section>

      {/* NOTICE */}

      <div
        className={
          styles.notice
        }
      >
        <div
          className={
            styles.noticeIcon
          }
        >
          <svg
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <circle
              cx="12"
              cy="12"
              r="9"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
            />

            <path
              d="M12 11v5M12 8h.01"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
            />
          </svg>
        </div>

        <div>
          <strong>
            Ưu tiên thông tin phản
            ánh đúng năng lực
          </strong>

          <p>
            Không cần thêm thật
            nhiều kỹ năng hoặc
            chứng chỉ. Hồ sơ rõ
            ràng, chính xác và có
            thể xác minh sẽ có giá
            trị hơn.
          </p>
        </div>
      </div>
    </div>
  );
};

/* =========================================================
   LOCAL COMPONENTS
========================================================= */

interface LanguageLevelFieldProps {
  label: string;

  value: LanguageProficiency;

  onChange: (
    value: LanguageProficiency,
  ) => void;
}

const LanguageLevelField = ({
  label,
  value,
  onChange,
}: LanguageLevelFieldProps) => {
  return (
    <div
      className={
        styles.field
      }
    >
      <label>
        {label}
      </label>

      <select
        value={value}
        onChange={(
          event,
        ) =>
          onChange(
            event.target
              .value as LanguageProficiency,
          )
        }
      >
        <LanguageOptions />
      </select>
    </div>
  );
};

const LanguageOptions = () => (
  <>
    <option value="">
      Chọn trình độ
    </option>

    <option value="basic">
      Cơ bản
    </option>

    <option value="conversational">
      Giao tiếp
    </option>

    <option value="professional">
      Làm việc chuyên nghiệp
    </option>

    <option value="fluent">
      Thành thạo
    </option>

    <option value="native">
      Bản ngữ
    </option>
  </>
);

export default SkillsLanguagesStep;