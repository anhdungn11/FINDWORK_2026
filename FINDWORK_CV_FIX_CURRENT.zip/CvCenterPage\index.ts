export { default } from "./CvCenterPage";
