export { default } from "./ResumeList";
